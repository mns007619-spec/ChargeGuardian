package com.chargeguardian.app

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.BatteryManager
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private var enabled = false
    private lateinit var toggle: Button
    private lateinit var protection: TextView
    private lateinit var battery: TextView
    private val prefs by lazy { getSharedPreferences("guard", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toggle = findViewById(R.id.toggleButton)
        protection = findViewById(R.id.protectionStatus)
        battery = findViewById(R.id.batteryStatus)
        enabled = prefs.getBoolean("enabled", false)
        updateUi()
        showBattery()
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 90)
        }
        toggle.setOnClickListener {
            enabled = !enabled
            prefs.edit().putBoolean("enabled", enabled).apply()
            if (enabled) {
                val intent = Intent(this, AlarmMonitorService::class.java).setAction(AlarmMonitorService.ACTION_START)
                ContextCompat.startForegroundService(this, intent)
            } else {
                stopService(Intent(this, AlarmMonitorService::class.java))
            }
            updateUi()
        }
    }

    override fun onResume() { super.onResume(); showBattery() }

    private fun showBattery() {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL || plugged != 0
        battery.text = if (pct >= 0) "البطارية الآن $pct٪ • ${if (charging) "الشاحن متصل" else "الشاحن غير متصل"}" else "تعذرت قراءة حالة البطارية"
    }

    private fun updateUi() {
        protection.text = if (enabled) "الحماية مفعّلة" else "الحماية متوقفة"
        toggle.text = if (enabled) "إيقاف الحماية" else "تشغيل الحماية"
    }
}
