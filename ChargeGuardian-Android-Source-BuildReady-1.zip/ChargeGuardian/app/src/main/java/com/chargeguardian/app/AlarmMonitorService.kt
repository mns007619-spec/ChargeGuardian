package com.chargeguardian.app

import android.app.*
import android.content.*
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import androidx.core.app.NotificationCompat

class AlarmMonitorService : Service() {
    companion object {
        const val ACTION_START = "com.chargeguardian.START"
        private const val CHANNEL = "charge_guard_channel"
        private const val NOTIFICATION_ID = 902
    }

    private val prefs by lazy { getSharedPreferences("guard", MODE_PRIVATE) }
    private var tone: ToneGenerator? = null
    private var alarmHandler: Handler? = null
    private var alarmRunning = false
    private var safeThisSession = false
    private var wasPlugged = false
    private var lastPercent = -1
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_POWER_CONNECTED -> { stopAlarm(); wasPlugged = true; if (lastPercent in 0..89) safeThisSession = false; updateBatteryState() }
                Intent.ACTION_POWER_DISCONNECTED -> {
                    if (lastPercent >= 90 || safeThisSession) stopAlarm() else startAlarm()
                    wasPlugged = false
                    prefs.edit().putBoolean("safe", safeThisSession).apply()
                }
                Intent.ACTION_BATTERY_CHANGED -> updateFromIntent(intent)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        registerReceiver(receiver, filter)
        val sticky = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        sticky?.let { updateFromIntent(it) }
        wasPlugged = isCurrentlyPlugged()
        safeThisSession = prefs.getBoolean("safe", false)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, notification())
        prefs.edit().putBoolean("enabled", true).apply()
        return START_STICKY
    }

    private fun updateBatteryState() {
        val sticky = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        sticky?.let { updateFromIntent(it) }
    }

    private fun updateFromIntent(intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level >= 0 && scale > 0) {
            lastPercent = level * 100 / scale
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            if (plugged && lastPercent >= 90) {
                safeThisSession = true
                prefs.edit().putBoolean("safe", true).apply()
            }
            if (plugged && !wasPlugged) {
                wasPlugged = true
                stopAlarm()
                if (lastPercent < 90) safeThisSession = false
            }
            if (status == BatteryManager.BATTERY_STATUS_FULL) safeThisSession = true
        }
    }

    private fun isCurrentlyPlugged(): Boolean {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return false
        return i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
    }

    private fun startAlarm() {
        if (alarmRunning) return
        alarmRunning = true
        tone = ToneGenerator(AudioManager.STREAM_ALARM, 100)
        alarmHandler = Handler(Looper.getMainLooper())
        val task = object : Runnable {
            override fun run() {
                if (!alarmRunning) return
                try { tone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 900) } catch (_: Exception) {}
                alarmHandler?.postDelayed(this, 1100)
            }
        }
        alarmHandler?.post(task)
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification("⚠ تم فصل الشاحن قبل 90٪! أعد توصيله لإيقاف الإنذار."))
    }

    private fun stopAlarm() {
        alarmRunning = false
        alarmHandler?.removeCallbacksAndMessages(null)
        alarmHandler = null
        try { tone?.stopTone(); tone?.release() } catch (_: Exception) {}
        tone = null
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification())
    }

    private fun notification(message: String = "الحماية تعمل • حدّ الإنذار 90٪"): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle("حارس الشحن")
            .setContentText(message)
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL, "مراقبة الشحن", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "إشعار دائم لحماية الشحن"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopAlarm()
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        prefs.edit().putBoolean("enabled", false).apply()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}
